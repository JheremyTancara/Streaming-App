namespace APIGatewayMovies.Configurations;

public class GatewaySettings
{
    public string BaseUrl { get; set; }
    public int MaxRequestLimit { get; set; }
}