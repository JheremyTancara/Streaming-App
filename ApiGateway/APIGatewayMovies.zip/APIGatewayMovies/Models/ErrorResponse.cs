namespace APIGatewayMovies.Models;

public class ErrorResponse
{
    public string ErrorMessage { get; set; }
    public int ErrorCode { get; set; }
}