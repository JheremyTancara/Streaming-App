namespace APIGatewayMovies.Services;

public class ActorDto
{
    public string Name { get; set; }
    public int Age { get; set; }
    public string Bio { get; set; }
    public string ProfilePictureUrl { get; set; }
}
